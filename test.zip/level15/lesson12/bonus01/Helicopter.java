package com.javarush.test.level15.lesson12.bonus01;

/**
 * Created by nemchinov on 31.10.2016.
 */
public class Helicopter implements Flyable
{
    @Override
    public void fly()
    {

    }
}

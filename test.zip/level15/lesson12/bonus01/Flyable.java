package com.javarush.test.level15.lesson12.bonus01;

public interface Flyable {
    void fly();
}

package com.javarush.test.level15.lesson12.home07;

public class Constants {
    public static String FILE_NAME = "D:/1.txt";
}

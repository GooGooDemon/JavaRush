package com.javarush.test.level17.lesson10.bonus01;

public enum Sex {
    MALE,
    FEMALE
}

package com.javarush.test.level17.lesson10.home07;

public interface Bean {   //это интерфейс-маркер
}

package com.javarush.test.level17.lesson10.home09;

import java.io.IOException;

public class CorruptedDataException extends IOException {
}

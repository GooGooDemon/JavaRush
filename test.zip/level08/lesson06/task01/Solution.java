package com.javarush.test.level08.lesson06.task01;

import java.util.*;

/* Создать два списка LinkedList и ArrayList
Нужно создать два списка – LinkedList и ArrayList.
*/

public class Solution
{
    public static Object createArrayList()
    {
        return new ArrayList<>();
    }

    public static Object createLinkedList()
    {
        //напишите тут ваш код
        return new LinkedList<>();
    }
}

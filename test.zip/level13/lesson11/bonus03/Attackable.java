package com.javarush.test.level13.lesson11.bonus03;

public interface Attackable
{
    BodyPart attack();
}

package com.javarush.test.level16.lesson13.bonus01.common;

public interface ImageReader {
}

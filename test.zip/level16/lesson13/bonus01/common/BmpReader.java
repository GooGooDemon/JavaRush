package com.javarush.test.level16.lesson13.bonus01.common;

/**
 * Created by nemchinov on 02.11.2016.
 */
public class BmpReader implements ImageReader
{
}

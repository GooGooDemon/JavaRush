package com.javarush.test.level16.lesson13.bonus02;

public interface Message {
    void showWarning();
}

package com.javarush.test.level11.lesson11.bonus02;

/* Нужно добавить в программу новую функциональность
Добавь общий базовый класс к классам-фигур:  (фигуры из шахмат).
*/

public class Solution
{
    public static void main(String[] args)
    {
    }

    public class Figure
    {
    }

    public class King extends Figure
    {
    }

    public class Queen extends Figure
    {
    }

    public class Rook extends Figure
    {
    }

    public class Knight extends Figure
    {
    }

    public class Bishop extends Figure
    {
    }

    public class Pawn extends Figure
    {
    }
}

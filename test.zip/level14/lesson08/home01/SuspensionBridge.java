package com.javarush.test.level14.lesson08.home01;

/**
 * Created by nemchinov on 21.10.2016.
 */
public class SuspensionBridge implements Bridge
{
    public int getCarsCount() { return 2; }
}

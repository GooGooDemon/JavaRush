package com.javarush.test.level14.lesson08.home05;

/**
 * Created by nemchinov on 24.10.2016.
 */
public class Mouse implements CompItem
{
    public String getName() {
        return "Mouse";
    }
}
package com.javarush.test.level14.lesson08.home05;

/**
 * Created by nemchinov on 24.10.2016.
 */
public class Monitor implements CompItem
{
    public String getName() {
        return "Monitor";
    }
}
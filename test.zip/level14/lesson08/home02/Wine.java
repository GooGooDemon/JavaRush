package com.javarush.test.level14.lesson08.home02;

/**
 * Created by nemchinov on 21.10.2016.
 */
public class Wine extends Drink
{
    public String getHolidayName() {
        return "День рождения";
    }
}

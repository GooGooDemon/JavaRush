package com.javarush.test.level14.lesson08.home02;

/**
 * Created by nemchinov on 21.10.2016.
 */
public abstract class Drink
{
    public void taste() {
        System.out.println("Вкусно");
    }
}

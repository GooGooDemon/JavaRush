package com.javarush.test.level14.lesson08.home02;

/**
 * Created by nemchinov on 21.10.2016.
 */
public class BubblyWine extends Wine
{
    public String getHolidayName() {
        return "Новый год";
    }
}

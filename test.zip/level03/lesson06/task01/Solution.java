package com.javarush.test.level03.lesson06.task01;

/* Мама мыла раму
Вывести на экран все возможные комбинации слов «Мама», «Мыла», «Раму».
Подсказка: их 6 штук. Каждую комбинацию вывести с новой строки. Слова не разделять. Пример:
МылаРамуМама
РамуМамаМыла
...
*/

public class Solution
{
    public static void main(String[] args)
    {
        //напишите тут ваш код
        System.out.println("МамаМылаРаму");
        System.out.println("МамаРамуМыла");

        System.out.println("РамуМамаМыла");
        System.out.println("РамуМылаМама");

        System.out.println("МылаМамаРаму");
        System.out.println("МылаРамуМама");

    }
}
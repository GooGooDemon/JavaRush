package com.javarush.test.level03.lesson06.task05;

import java.io.*;
import java.util.Scanner;


/* Изучаем японский
Выведи на экран 日本語
*/

public class Solution
{
    public static void main(String[] args) throws IOException
    {
        System.out.print("日本語");

        //напишите тут ваш код
        /*InputStream inputStream = System.in;
        Reader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        System.out.println("Using a BufferedReader object");
        System.out.print("Enter name: ");
        String name1 = bufferedReader.readLine(); //читаем строку с клавиатуры
        System.out.print("Enter age: ");
        String sAge = bufferedReader.readLine(); //читаем строку с клавиатуры
        int nAge = Integer.parseInt(sAge); //преобразовываем строку в число.

        System.out.println("Using a Scanner object");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name2 = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();*/
    }
}
package com.javarush.test.level12.lesson06.task01;

/* Абстрактный класс Pet
Сделать класс Pet абстрактным.
*/

public class Solution
{
    public static void main(String[] args)
    {

    }

    public abstract class Pet
    {
        public String getName()
        {
            return "Я - котенок";
        }
    }

}

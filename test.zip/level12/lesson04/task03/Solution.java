package com.javarush.test.level12.lesson04.task03;

/* Пять методов print с разными параметрами
Написать пять методов print с разными параметрами.
*/

public class Solution
{
    public static void main(String[] args)
    {

    }

    public static void print(int x) {}

    public static void print(int x, int y) {}

    public static void print(String text, int x, int y) {}

    public static void print(String text) {}

    public static void print(String name, Object object) {}

}
